var config = {};

config.admin={};

config.app={};

config.admin.name="Ivan guerrero";
config.admin.email="";
config.app.name="venue backend";
config.app.url="";

module.exports=config