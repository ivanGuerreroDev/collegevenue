import INITIAL_STATE from "../../data/sidebar-nav-items";
const sidebarItems = (state = INITIAL_STATE, action) => {
  switch (action.type) {
    default:
      return state
  }
}

export default sidebarItems