import DefaultLayout from "./Default";
import LoginLayout from "./LoginLayout";

export { DefaultLayout, LoginLayout  };
